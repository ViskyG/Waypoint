#!/usr/bin/env python3
import hashlib, importlib.util, json, sqlite3, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('protocol',ROOT/'experiments/P04/protocol.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
class Tailer:
    def __init__(self): self.pending=b''
    def feed(self,data):
        self.pending+=data; result=[]
        while b'\n' in self.pending:
            line,self.pending=self.pending.split(b'\n',1)
            if line: result.append(json.loads(line))
        return result
def main():
    db=ROOT/'experiments/P04/protocol.sqlite'; conn=sqlite3.connect(db)
    # Only this spike's generated namespace; P04 and hook rows are untouched.
    conn.execute("DELETE FROM events WHERE id LIKE 'replay:%'"); conn.commit()
    fixture=[json.loads(x) for x in (ROOT/'fixtures/events.synthetic.jsonl').read_text().splitlines()]
    extras=[{'event_id':'extra-unknown','source':'SYNTHETIC','type':'future.type','agent_id':'A9'},
            {'event_id':'extra-missing-block','source':'SYNTHETIC','type':'agent.message','agent_id':'A2','block_ids':['MISSING']},
            {'event_id':'extra-stale','source':'SYNTHETIC','type':'observation_gap','block_ids':[]}]
    events=fixture+extras
    def ingest(es):
        for e in es:
            mod.persist(conn,'replay:'+e['source']+':'+e['event_id'],json.dumps(e,sort_keys=True))
        conn.commit()
    def snapshot(): return conn.execute("SELECT id,body FROM events WHERE id LIKE 'replay:%' ORDER BY id").fetchall()
    # Gap then backfill. Unknown references retained as observations, not rejected agent commands.
    ingest(events[:5]+events[10:]); incomplete=snapshot(); ingest(events[5:10]); full=snapshot()
    assert len(full)==20 and len(incomplete)<len(full)
    conn.close(); conn=sqlite3.connect(db); ingest(events)
    assert snapshot()==full
    recovered=[json.loads(body) for _,body in full]
    assert next(e for e in recovered if e['event_id']=='synth-012')['at']=='2026-10-16T10:03:00+04:00'
    assert any(e['type']=='future.type' and 'block_ids' not in e for e in recovered)
    assert any(e.get('block_ids')==['MISSING'] for e in recovered)
    tail=Tailer(); raw=(json.dumps(extras[0])+'\n').encode(); split=len(raw)//2
    assert tail.feed(raw[:split])==[]; parsed=tail.feed(raw[split:]); assert len(parsed)==1
    ingest(parsed); assert snapshot()==full
    # Restart after partial byte offset: retain incomplete bytes or re-read from last complete newline.
    resumed=Tailer(); assert resumed.feed(raw)==parsed
    same_other_source=dict(extras[0],source='OTHER_SYNTHETIC'); ingest([same_other_source]); assert len(snapshot())==21
    def projection(es,connected):
        agents={}; statuses={}; tests={}
        for e in sorted(es,key=lambda e:e.get('at','')):
            if e['type']=='agent.started': agents[e['agent_id']]='active'
            if e['type']=='agent.stopped': agents[e['agent_id']]='stopped'
            for b in e.get('block_ids',[]):
                if e['type']=='block.status': statuses[b]=e['payload']['status']
                if e['type']=='test.result': tests[b]=e['payload']
        return {'agents':agents,'statuses':statuses,'tests':tests,
                'observation':'connected' if connected else 'unknown',
                'last_at':max(e.get('at','') for e in es)}
    state=projection(recovered,False)
    assert state['statuses']['W-03.1']=='done' and state['tests']['W-03.1']['failed']==2
    assert state['agents']['O1']=='stopped' and state['agents']['A4']=='active'
    assert state['observation']=='unknown' and state['last_at']
    assert projection([json.loads(body) for _,body in snapshot()],False)==state
    bulk=[{'event_id':f'bulk-{i}','source':'SYNTHETIC','type':'agent.message','agent_id':'A2','block_ids':['W-02'],'seq':i,'payload':{'text':'synthetic payload'}} for i in range(10000)]
    started=time.perf_counter(); ingest(bulk); ingest_ms=(time.perf_counter()-started)*1000
    started=time.perf_counter(); ingest(bulk); repeat_ms=(time.perf_counter()-started)*1000
    started=time.perf_counter(); rows=snapshot(); restored=[json.loads(x[1]) for x in rows]; restore_ms=(time.perf_counter()-started)*1000
    assert len(rows)==10021
    out={'source':'SYNTHETIC','fixture_unique_plus_extras':20,'cross_source_unique':True,
         'bulk_unique':10000,'collector_records':len(rows),'total_db_records':conn.execute('SELECT count(*) FROM events').fetchone()[0],
         'ingest_ms':ingest_ms,'repeat_ms':repeat_ms,'restore_ms':restore_ms,'db_bytes':db.stat().st_size,
         'timing':'one run; perf_counter; shared P04 SQLite backend+database; bulk transaction per ingestion batch',
         'invariants':{k:'PASS' for k in ['dedupe','replay_restart','early_timestamp_retained','unknown_type_retained','missing_blocks_retained','partial_line','source_plus_id','gap_backfill','permanent_gap_unknown','parent_stop_child_active','done_with_red_tests']},
         'source_down_display':'unknown; last observed timestamp; never infer active from silence',
         'real_source_key_limit':'rollouts lack guaranteed universal event ID: source generation + complete-line byte offset; rotation requires reconciliation, not exactly-once guarantee',
         'checks':'PASS'}
    conn.close(); (ROOT/'reports/P06_observation.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
