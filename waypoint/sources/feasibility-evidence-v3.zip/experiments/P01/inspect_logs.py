#!/usr/bin/env python3
"""Read one rollout in place; persist only schema and counters, never values."""
import collections, hashlib, json, os, platform, shutil, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
REPORTS = ROOT/'reports'
REPORTS.mkdir(exist_ok=True)
def dump(name, data):
    (REPORTS/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
versions = {}
for command in ['codex','python3','node','npm','git']:
    p = subprocess.run([command,'--version'],capture_output=True,text=True)
    versions[command] = p.stdout.strip()
home = Path.home()/'.codex'
paths = list((home/'sessions').rglob('*.jsonl'))
config_text = (home/'config.toml').read_text() if (home/'config.toml').exists() else ''
# Do not dump configuration or arbitrary values.
history = 'unspecified (default not inferred)'
in_history = False
for line in config_text.splitlines():
    if line.strip().startswith('['): in_history = line.strip() == '[history]'
    if in_history and line.strip().startswith('persistence'):
        value = line.partition('=')[2].strip().strip('"\'')
        history = value if value in ['save-all','none'] else 'unknown'
dump('capabilities.json', {'versions':versions,'os':platform.system()+' '+platform.release(),
 'app_server_help':'yes','exec_json_help':'yes','session_jsonl_files':len(paths),
 'sources':['$HOME/.codex/sessions/**/*.jsonl','$HOME/.codex/history.jsonl'],
 'history_persistence':history,'hooks':'help mentions hook trust; execution NOT_TESTED',
 'browser':'CUA browser tool available; local Playwright Python absent',
 'live_external_subscription':'unknown: not established by help'})
if not paths:
    dump('P01_observation.json',{'readable_rollout':False}); raise SystemExit()
p = max(paths,key=lambda x:x.stat().st_mtime)
limit = p.stat().st_size
raw = p.open('rb').read(limit)
counts = collections.Counter(); fields = collections.defaultdict(collections.Counter)
roles = collections.Counter(); tools = collections.Counter(); ids=collections.Counter()
errors=0
def walk(obj,prefix=''):
    if isinstance(obj,dict):
        for k,v in obj.items():
            if '/' in k or '\\' in k: k = '<dynamic-key>'
            if k in ['session_id','thread_id','turn_id','item_id','call_id','id','parent_thread_id']:
                ids[k]+=1
            if prefix.count('.')<3:
                fields[prefix+k][type(v).__name__]+=1
            if k not in ['text','content','arguments','output','instructions','input']:
                walk(v,prefix+k+'.')
    elif isinstance(obj,list) and prefix.count('.')<3:
        for v in obj: walk(v,prefix+'[].')
for line in raw.splitlines():
    try: event=json.loads(line)
    except (ValueError,UnicodeError): errors+=1; continue
    typ=event.get('type','unknown'); payload=event.get('payload',{})
    subtype=payload.get('type','unknown') if isinstance(payload,dict) else 'unknown'
    counts[typ+'/'+subtype]+=1
    if isinstance(payload,dict):
        if payload.get('role') in ['user','assistant','developer','system','tool']: roles[payload['role']]+=1
        if subtype in ['function_call','custom_tool_call']: tools[subtype]+=1
    walk(event)
# Stable byte prefix read twice: hash-based logical key; full line content never persisted.
hashes={hashlib.sha256(x).digest() for x in raw.splitlines()}
again=p.open('rb').read(limit)
new={hashlib.sha256(x).digest() for x in again.splitlines()}-hashes
dump('P01_observation.json',{'readable_rollout':True,'source':'most recently modified own-user rollout',
 'snapshot_bytes':limit,'complete_lines':len(raw.splitlines()),'malformed_lines':errors,
 'event_types':dict(counts),'roles':dict(roles),'tools':dict(tools),'id_field_counts':dict(ids),
 'schema_fields':dict(fields),'repeat_prefix_new_events':len(new),
 'identity':'source file + byte offset; hash for repeat test; no guaranteed independent event id',
 'live_latency':'NOT_TESTED','raw_reasoning':'not inferred; opaque/encrypted or summary fields do not prove raw thoughts'})
print('P00/P01 sanitized observations written; no transcript content exported')
