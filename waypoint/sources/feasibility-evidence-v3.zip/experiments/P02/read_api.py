#!/usr/bin/env python3
import collections, hashlib, json, os, re, selectors, sqlite3, subprocess, sys, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
state=Path(tempfile.mkdtemp(prefix='runtime-state-',dir=HERE)); state.chmod(0o700)
logs=state/'logs'; logs.mkdir()
probe_home=state/'codex-home'; probe_home.mkdir(mode=0o700)
# Scope the documented home override to this child, leaving our environment intact.
# No auth or user config is copied. Original rollout directories remain read-only.
probe_environment=os.environ.copy()
probe_environment['CODEX_HOME']=str(probe_home)
for dirname in ['sessions','archived_sessions']:
    original_dir=Path.home()/'.codex'/dirname
    if original_dir.is_dir(): (probe_home/dirname).symlink_to(original_dir,target_is_directory=True)
# Consistent local snapshot avoids changing or reindexing the user's original DB.
# The snapshot is private scratch, never included in export archives.
original_db=Path.home()/'.codex/state_5.sqlite'
source=sqlite3.connect('file:'+str(original_db)+'?mode=ro',uri=True)
source.execute('PRAGMA query_only=ON')
destination=sqlite3.connect(state/original_db.name)
source.backup(destination); destination.close(); source.close()
guard_paths=[Path.home()/'.codex'/n for n in ['config.toml','auth.json']]
def guards(): return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in guard_paths if p.is_file()}
before_guards=guards()
command=['codex','-c','sqlite_home='+json.dumps(str(state)),'-c','log_dir='+json.dumps(str(logs)),'app-server','--stdio']
allowed={'initialize','initialized','thread/list','thread/read','thread/turns/list','thread/items/list','thread/loaded/list'}
proc=subprocess.Popen(command,cwd=HERE,env=probe_environment,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
sel=selectors.DefaultSelector()
for stream in [proc.stdout,proc.stderr]:
    os.set_blocking(stream.fileno(),False); sel.register(stream,selectors.EVENT_READ)
buffers={proc.stdout:b'',proc.stderr:b''}; notifications=collections.Counter(); calls=[]; err_categories=collections.Counter(); seq=0; stderr_safe=[]
external_live={'status':'NOT_TESTED'}
def safe_shape(body):
    data=body.get('data',[])
    result={'turn_count':len(data),'item_count':sum(len(t.get('items',[])) for t in data),
      'items_views':sorted({t.get('itemsView','unknown') for t in data}),
      'item_types':dict(collections.Counter(i.get('type','unknown') for t in data for i in t.get('items',[]))),
      'turn_statuses':sorted({t.get('status','unknown') for t in data})}
    return result
def request(method,params,notification=False):
    global seq
    assert method in allowed
    seq+=1; msg={'method':method,'params':params}
    if not notification: msg['id']=seq
    proc.stdin.write(json.dumps(msg).encode()+b'\n'); proc.stdin.flush()
    if notification: return {}
    started=time.monotonic()
    deadline=started+(45 if method=='initialize' else 15)
    while time.monotonic()<deadline:
        for key,_ in sel.select(.2):
            data=os.read(key.fileobj.fileno(),65536)
            if not data:
                sel.unregister(key.fileobj); continue
            buffers[key.fileobj]+=data
            while b'\n' in buffers[key.fileobj]:
                line,buffers[key.fileobj]=buffers[key.fileobj].split(b'\n',1)
                if key.fileobj is proc.stderr:
                    message=line.decode('utf-8',errors='replace')
                    message=re.sub(r'\x1b\[[0-9;]*m','',message)
                    message=re.sub(r'/[^\s\"\']+','<path>',message)
                    message=re.sub(r'\b[0-9a-f]{8}-[0-9a-f-]{27,}\b','<id>',message)
                    if any(x in message.lower() for x in ['token','bearer','password','secret','api_key']): message='<sensitive diagnostic omitted>'
                    stderr_safe.append(message)
                    for fragment in ['Read-only file system','Permission denied','error','WARN']:
                        if fragment.lower().encode() in line.lower(): err_categories[fragment]+=1
                    continue
                try: result=json.loads(line)
                except ValueError: continue
                if 'id' not in result: notifications[result.get('method','unknown')]+=1
                if result.get('id')==seq:
                    summary={'method':method,'param_keys':list(params),'result_keys':list(result.get('result',{})),
                             'error_code':result.get('error',{}).get('code'),'elapsed_ms':(time.monotonic()-started)*1000}
                    # API error messages may include paths; retain only known classification.
                    message=result.get('error',{}).get('message','')
                    summary['error_kind']=next((x for x in ['unknown variant','not found','not supported','experimental','invalid','legacy'] if x in message.lower()),None)
                    body=result.get('result',{})
                    if method=='thread/turns/list' and body: summary['history_shape']=safe_shape(body)
                    for k,v in body.items():
                        if isinstance(v,list): summary[k+'_count']=len(v)
                    summary['cursor_present']=bool(body.get('nextCursor'))
                    if 'thread' in body: summary['thread_status']=body['thread'].get('status')
                    calls.append(summary); return body
        if proc.poll() is not None: break
    calls.append({'method':method,'timeout_or_exit':True,'returncode':proc.poll()}); return {}
try:
    handshake=request('initialize',{'clientInfo':{'name':'waypoint_readonly_probe','version':'0.1'}})
    if handshake:
        request('initialized',{},True)
        listing=request('thread/list',{'limit':2})
        if listing.get('nextCursor'): request('thread/list',{'limit':2,'cursor':listing['nextCursor']})
        threads=listing.get('data',[])
        if threads:
            tid=threads[0]['id']
            request('thread/read',{'threadId':tid,'includeTurns':False})
            turns=request('thread/turns/list',{'threadId':tid,'limit':1})
            turn_data=turns.get('data',[])
            request('thread/items/list',{'threadId':tid,'turnId':turn_data[0]['id'] if turn_data else 'unavailable','limit':1})
        request('thread/loaded/list',{})
        if '--live-check' in sys.argv:
            tid=os.environ.get('CODEX_THREAD_ID')
            if tid:
                originals=list((Path.home()/'.codex/sessions').rglob('*'+tid+'*.jsonl'))
                path=originals[0] if len(originals)==1 else None
                before_bytes=path.stat().st_size if path else None
                prefix_hash=hashlib.sha256(path.read_bytes()).digest() if path else None
                before_thread=request('thread/read',{'threadId':tid,'includeTurns':False})
                before_history=request('thread/turns/list',{'threadId':tid,'limit':1,'itemsView':'full'})
                marker=HERE/'continue-live-check'
                if marker.exists(): marker.unlink()
                print(json.dumps({'phase':'READY_FOR_NATURAL_CLIENT_ACTIVITY','current_client_thread_targeted':True,'source_file_found':bool(path)}),flush=True)
                deadline=time.monotonic()+45
                while not marker.exists() and time.monotonic()<deadline:
                    for key,_ in sel.select(.1):
                        data=os.read(key.fileobj.fileno(),65536)
                        if not data: continue
                        buffers[key.fileobj]+=data
                        # Live notification payloads stay in memory; only method counts exported.
                        if key.fileobj is proc.stdout:
                            while b'\n' in buffers[key.fileobj]:
                                line,buffers[key.fileobj]=buffers[key.fileobj].split(b'\n',1)
                                try: notice=json.loads(line)
                                except ValueError:continue
                                if 'id' not in notice:notifications[notice.get('method','unknown')]+=1
                after_thread=request('thread/read',{'threadId':tid,'includeTurns':False})
                after_history=request('thread/turns/list',{'threadId':tid,'limit':1,'itemsView':'full'})
                external_live={'status':'OBSERVED_CURRENT_CLIENT_PERSISTED_STATE',
                  'target':'already-running originating Codex client of this task; separate from probe server; no new turn',
                  'source_file_found':bool(path),'source_bytes_before':before_bytes,'source_bytes_after':path.stat().st_size if path else None,
                  'source_existing_prefix_unchanged':hashlib.sha256(path.open('rb').read(before_bytes)).digest()==prefix_hash if path else None,
                  'thread_status_before':before_thread.get('thread',{}).get('status'),
                  'thread_status_after':after_thread.get('thread',{}).get('status'),
                  'history_before':safe_shape(before_history),'history_after':safe_shape(after_history),
                  'loaded_after':len(request('thread/loaded/list',{}).get('data',[])),
                  'live_thread_notifications':{k:v for k,v in notifications.items() if k.startswith(('thread/','turn/','item/'))},
                  'natural_activity_window_completed':marker.exists()}
            else: external_live={'status':'NOT_TESTED','reason':'current client thread id unavailable'}
finally:
    proc.stdin.close()
    try: proc.wait(timeout=3)
    except subprocess.TimeoutExpired: proc.terminate(); proc.wait(timeout=3)
out={'calls':calls,'notification_counts':dict(notifications),'stderr_categories':dict(err_categories),'stderr_sanitized':stderr_safe,
     'runtime_isolation':{'sqlite_home':str(state.relative_to(ROOT)),'log_dir':str(logs.relative_to(ROOT)),
       'state_snapshot':'SQLite backup from original mode=ro, query_only=ON; snapshot not exported',
       'process_local_codex_home':str(probe_home.relative_to(ROOT)),
       'rollout_access':'symlinks to originals; read-only enforced by sandbox; no auth/config copied',
       'config_auth_hashes_unchanged':guards()==before_guards,'override_scope':'this process only; original HOME/auth/config unchanged'},
     'new_turn_commands_sent':0,'own_process_closed':proc.poll() is not None,
     'external_live':external_live,
     'side_effect_limit':'read-only RPC allowlist; global HOME read-only by sandbox; cannot infer absence of all internal effects'}
(ROOT/'reports/P02_observation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
