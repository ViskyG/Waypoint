#!/usr/bin/env python3
import hashlib, json, os, resource, selectors, sqlite3, statistics, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
INSTRUCTION='Send one JSON line: op focus/status/link_event/tests; event_id unique; agent_id for focus; block_ids array; status free text; edge optional; tests list with result and evidence_ref. Read via get_block or get_focus. Timeout after one second; continue work if observer unavailable.'
def persist(conn, key, body):
    old=conn.execute('SELECT body FROM events WHERE id=?',(key,)).fetchone()
    if old and old[0]!=body: raise ValueError('event_id_conflict')
    conn.execute('INSERT OR IGNORE INTO events VALUES(?,?)',(key,body))
    return bool(old)
def worker(db):
    conn=sqlite3.connect(db)
    conn.execute('CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, body TEXT NOT NULL)')
    nodes={n['id'] for n in json.loads((ROOT/'fixtures/graph-v1.json').read_text())['nodes']}
    for line in sys.stdin:
        try:
            e=json.loads(line); op=e['op']
            if op in ['get_block','get_focus']:
                rows=[json.loads(v) for v, in conn.execute('SELECT body FROM events ORDER BY rowid')]
                if op=='get_block': result=[r for r in rows if e['block_id'] in r.get('block_ids',[])]
                else:
                    f=[r for r in rows if r['op']=='focus' and r.get('agent_id')==e['agent_id']]
                    result=f[-1]['block_ids'] if f else []
                response={'ok':True,'data':result}
            else:
                if op not in ['focus','status','link_event','tests']: raise ValueError('unknown_operation')
                if not isinstance(e.get('event_id'),str): raise ValueError('missing_event_id')
                if not isinstance(e.get('block_ids'),list): raise ValueError('invalid_blocks')
                if any(b not in nodes for b in e['block_ids']): raise ValueError('unknown_block')
                if e.get('edge') and any(b not in nodes for b in e['edge'].values()): raise ValueError('unknown_edge_block')
                if op=='focus' and not e.get('agent_id'): raise ValueError('missing_agent_id')
                if op=='status' and not isinstance(e.get('status'),str): raise ValueError('invalid_status')
                body=json.dumps(e,sort_keys=True)
                duplicate=persist(conn,e['event_id'],body); conn.commit()
                response={'ok':True,'duplicate':duplicate}
        except (KeyError,ValueError,TypeError) as ex: response={'ok':False,'error':str(ex)}
        print(json.dumps(response),flush=True)
def bench():
    db=HERE/'protocol.sqlite'
    if db.exists(): db.unlink() # own generated scratch only
    p=subprocess.Popen([sys.executable,__file__,'--worker',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    sel=selectors.DefaultSelector(); sel.register(p.stdout,selectors.EVENT_READ)
    def call(e,timeout=1):
        p.stdin.write(json.dumps(e)+'\n'); p.stdin.flush()
        if not sel.select(timeout): return {'ok':False,'error':'observer_timeout'}
        return json.loads(p.stdout.readline())
    times=[]; totalbytes=0
    try:
        for i in range(1000):
            op=['focus','status','link_event','tests'][i%4]
            e={'op':op,'event_id':f'bench-{i}','agent_id':'A2','block_ids':['W-02','W-03']}
            if op=='status': e['status']='needs-human-input'
            if op=='link_event': e.update(source_event_id='synth-004',edge={'from':'W-01','to':'W-02'})
            if op=='tests': e['tests']=[{'test_id':'smoke','result':'passed','evidence_ref':'synthetic-1'}]
            totalbytes+=len((json.dumps(e)+'\n').encode()); start=time.perf_counter_ns()
            assert call(e)['ok']; times.append((time.perf_counter_ns()-start)/1e6)
        before=hashlib.sha256(db.read_bytes()).hexdigest()
        block=call({'op':'get_block','block_id':'W-02'})
        focus=call({'op':'get_focus','agent_id':'A2'})
        assert len(block['data'])==1000 and focus['data']==['W-02','W-03']
        assert before==hashlib.sha256(db.read_bytes()).hexdigest()
        assert call(e)['duplicate']
        assert call(dict(e,event_id='bad',block_ids=['MISSING']))['error']=='unknown_block'
        assert before==hashlib.sha256(db.read_bytes()).hexdigest()
        rss_kib=int(next(x for x in Path(f'/proc/{p.pid}/status').read_text().splitlines() if x.startswith('VmRSS:')).split()[1])
    finally:
        p.stdin.close(); p.wait(timeout=2)
    # Hung synthetic observer: bounded read; this process never controls Codex.
    hung=subprocess.Popen([sys.executable,'-c','import time; time.sleep(2)'],stdout=subprocess.PIPE)
    hsel=selectors.DefaultSelector(); hsel.register(hung.stdout,selectors.EVENT_READ)
    start=time.perf_counter(); ready=hsel.select(.1); elapsed=time.perf_counter()-start
    hung.terminate(); hung.wait(); assert not ready and elapsed<.5
    n=sqlite3.connect(db).execute('SELECT count(*) FROM events').fetchone()[0]; assert n==1000
    out={'source':'SYNTHETIC','operations':1000,'timing':'one process; JSONL stdin/stdout roundtrip + SQLite commit; perf_counter_ns; cold first request included',
         'p50_ms':statistics.median(times),'p95_ms':sorted(times)[949],'request_bytes':totalbytes,
         'db_bytes':db.stat().st_size,'db_bytes_per_record':db.stat().st_size/n,'worker_rss_kib':rss_kib,
         'instruction_words':len(INSTRUCTION.split()),'instruction':INSTRUCTION,'model_calls':0,
         'read_unchanged':True,'idempotence':True,'invalid_request_unchanged':True,
         'free_status':'needs-human-input','timeout_ms':elapsed*1000,'checks':'PASS'}
    (ROOT/'reports/P04_observation.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':
    if '--worker' in sys.argv: worker(sys.argv[-1])
    else: bench()
