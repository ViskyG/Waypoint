#!/usr/bin/env python3
"""Inventory own-user Codex process transports; export metadata, never argv/env dumps."""
import json,os,socket,stat
from pathlib import Path
import psutil
ROOT=Path(__file__).resolve().parents[2]
def safe_path(p):
 return str(p).replace(str(Path.home()),'$USER_HOME')
rows=[];candidates=[]
for p in psutil.process_iter(['pid','ppid','name','uids']):
 try:
  if p.info['uids'].real!=os.getuid():continue
  args=p.cmdline()
  exe=Path(args[0]).name if args else p.info['name']
  if 'codex' not in exe.lower() and 'codex' not in p.info['name'].lower():continue
  transports={}
  for i,arg in enumerate(args):
   if arg in ['app-server','--stdio']:transports[arg]=True
   if arg in ['--listen','--remote'] and i+1<len(args):
    val=args[i+1];transports[arg]=val.split('?')[0] if '@' not in val else '<authenticated URL omitted>'
  connections=[]
  for conn in p.connections(kind='all'):
   if conn.family==socket.AF_UNIX:
    if conn.laddr:
     connections.append({'family':'unix','path':safe_path(conn.laddr),'status':conn.status})
     if '--listen' in transports or 'app-server' in transports:candidates.append({'path':conn.laddr,'pid':p.pid})
   elif conn.status=='LISTEN':connections.append({'family':'tcp','ip':conn.laddr.ip,'port':conn.laddr.port,'status':'LISTEN'})
  rows.append({'pid':p.pid,'ppid':p.ppid(),'executable_name':exe,'transport_args':transports,'connections':connections})
 except (psutil.AccessDenied,psutil.NoSuchProcess):pass
# Known per-user runtime location only; do not scan unrelated sockets.
paths=[]
base=Path.home()/'.codex'
for p in base.rglob('*'):
 if any(x in p.parts for x in ['sessions','archived_sessions','packages','plugins','skills']):continue
 try:
  if stat.S_ISSOCK(p.lstat().st_mode):paths.append(safe_path(p))
 except OSError:pass
result={'own_user_codex_processes':rows,'codex_home_socket_paths':paths,'scope':'host PID/network namespace; only current user; no argv/env values exported'}
(ROOT/'reports/P09_inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
