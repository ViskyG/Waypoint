#!/usr/bin/env python3
"""Verify real existing lineage from session metadata and returned spawn IDs.
Only aliases, schemas and equality checks leave memory; no raw identifiers/text.
"""
import collections,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
base=Path.home()/'.codex';records={};fields=collections.Counter()
for p in list((base/'sessions').rglob('*.jsonl'))+list((base/'archived_sessions').rglob('*.jsonl')):
 try:
  with p.open() as f:e=json.loads(f.readline(3000000))
  if e.get('type')!='session_meta':continue
  m=e['payload'];records[m['id']]=(m,p)
  for k,v in m.items():fields[k+':'+type(v).__name__]+=1
 except (OSError,ValueError):pass
chains=[];explicit=[];depths=[];cycles=0;missing=0
for ident,(m,p) in records.items():
 seen=set();cur=ident;depth=0
 while cur in records and records[cur][0].get('parent_thread_id'):
  if cur in seen:cycles+=1;break
  seen.add(cur);cur=records[cur][0]['parent_thread_id'];depth+=1
 if cur not in records:missing+=1
 depths.append(depth)
 parent=m.get('parent_thread_id');grand=records.get(parent,({},))[0].get('parent_thread_id')
 if parent in records and grand in records:
  chain=[grand,parent,ident];chains.append(chain)
  if not records[grand][0].get('parent_thread_id') and all(isinstance(records[x][0].get('source'),dict) and 'thread_spawn' in records[x][0]['source'].get('subagent',{}) for x in chain[1:]):explicit.append(chain)
assert explicit,'No real explicit depth-2 chain found'
chain=max(explicit,key=lambda c:records[c[-1]][0]['timestamp']);aliases=dict(zip(chain,['R0','A1','A2']))
nodes=[];proofs=[]
for pos,ident in enumerate(chain):
 m,p=records[ident];src=m.get('source',{});spawn=src.get('subagent',{}).get('thread_spawn',{}) if isinstance(src,dict) else {}
 if pos:
  assert m['parent_thread_id']==chain[pos-1]
  assert spawn['parent_thread_id']==chain[pos-1] and spawn['depth']==pos
 nodes.append({'alias':aliases[ident],'parent_alias':aliases.get(m.get('parent_thread_id')),'source_depth':spawn.get('depth'),
  'explicit_parent_field':bool(m.get('parent_thread_id')),'metadata_session_id_equals_id':m.get('session_id')==m['id'],
  'session_id_matches_root_container':m.get('session_id')==records[chain[0]][0].get('session_id'),
  'thread_spawn_parent_matches_metadata':spawn.get('parent_thread_id')==m.get('parent_thread_id') if pos else None,
  'agent_path_present':bool(m.get('agent_path') or spawn.get('agent_path')),'proof_location':'session_meta payload, first JSONL line'})
 if pos<2:
  child=chain[pos+1];calls={};outputs=[];matching_output=False;matching_task_path=False;spawn_calls=0
  for raw in p.open():
   try:e=json.loads(raw)
   except ValueError:continue
   pay=e.get('payload',{});typ=pay.get('type') if isinstance(pay,dict) else None
   if e.get('type')=='response_item' and typ in ['function_call','custom_tool_call']:
    name=pay.get('name','');cid=pay.get('call_id')
    if 'spawn_agent' in name:
     spawn_calls+=1
     if cid:calls[cid]=True
   if e.get('type')=='response_item' and typ in ['function_call_output','custom_tool_call_output']:
    if pay.get('call_id') in calls:
     if child in json.dumps(pay.get('output')):matching_output=True
     try:decoded=json.loads(pay.get('output',''))
     except (ValueError,TypeError):decoded={}
     child_path=records[child][0].get('agent_path')
     if child_path and isinstance(decoded,dict) and decoded.get('task_name')==child_path:matching_task_path=True
  proofs.append({'parent_alias':aliases[ident],'child_alias':aliases[child],
   'parent_session_spawn_call_count':spawn_calls,'spawn_output_contains_same_child_id':matching_output,
   'parent_spawn_output_task_name_equals_child_agent_path':matching_task_path,
   'primary_proof':'matching parent fields in child metadata + numeric depth + parent spawn result task_name matches child agent_path'})
  assert matching_task_path,'Parent spawn result must corroborate the selected real child'
result={'status':'PASS','evidence':'REAL','source':'existing own-user Codex rollouts; historical actual sessions, not synthetic fixtures or newly spawned agents',
 'sessions_indexed':len(records),'explicit_parent_metadata_count':sum('parent_thread_id' in m for m,p in records.values()),
 'two_edge_chains_with_all_files':len(chains),'strict_explicit_root_depth_1_depth_2_chains':len(explicit),
 'max_observed_parent_hops':max(depths),'missing_ancestor_paths':missing,'detected_cycles':cycles,
 'chosen_chain':nodes,'edge_corrobation':proofs,'metadata_field_schema_counts':dict(fields),
 'new_agents_spawned':0,'new_model_turns':0,'runtime_live_tree_observation':False,
 'limits':'historical real lineage proves persisted identifiers and actual prior nesting; not a currently running 3-agent orchestration or completeness of live API'}
(ROOT/'reports/P11_real_lineage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
