#!/usr/bin/env python3
"""Use only existing endpoints; no daemon start/restart and no inference."""
import json,os,socket,time
from pathlib import Path
import psutil
ROOT=Path(__file__).resolve().parents[2]
inventory=json.loads((ROOT/'reports/P09_inventory.json').read_text())
current=next(r for r in inventory['own_user_codex_processes'] if r.get('current_rollout_open'))
parent=psutil.Process(current['ppid']);bridge=next(c.laddr for c in parent.connections(kind='unix') if c.laddr and 'codex-bridge' in c.laddr)
s=socket.socket(socket.AF_UNIX);s.settimeout(3);s.connect(bridge);t=time.monotonic();s.sendall(b'{"op":"status"}\n');raw=b''
while not raw.endswith(b'\n'):raw+=s.recv(65536)
s.close();status=json.loads(raw)
control=Path.home()/'.codex/app-server-control/app-server-control.sock'
s=socket.socket(socket.AF_UNIX);s.settimeout(2)
try:s.connect(str(control));control_result={'connect':'success'}
except OSError as e:control_result={'connect':'failed','errno':e.errno,'error_class':'connection_refused' if e.errno==111 else type(e).__name__}
finally:s.close()
tid=os.environ['CODEX_THREAD_ID']
out={'evidence':'REAL','current_server_pid':current['pid'],'current_server_parent':current.get('parent_executable'),
 'current_rollout_open_in_server':True,'server_stdio':current.get('fd0_kind')=='pipe' and current.get('fd1_kind')=='pipe',
 'current_server_listening_transports':[],'standard_app_server_control':control_result,
 'other_unix_interfaces':{'vscode_ipc':{'existing':True,'owner_executable':'code','protocol':'private 4-byte-length JSON IPC, not WebSocket'},
 'process_hud_bridge':{'existing':True,'allowed_ops_from_installed_source':['status','deliver'],'sent_op':'status',
 'initialized':status.get('initialized'),'server_pid_matches_current':status.get('server_pid')==current['pid'],
 'current_thread_known':tid in status.get('threads',[]),'current_thread_active':tid in status.get('active_turns',{}),'roundtrip_ms':(time.monotonic()-t)*1000,
 'arbitrary_rpc_or_event_subscription_supported':False}},
 'new_daemon_started':False,'existing_clients_restarted':False,'existing_client_transport_changed':False,
 'conclusion':'No shared official App Server listener on this current executor; existing private VS Code IPC follower stream is tested separately'}
(ROOT/'reports/P09_transports.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
