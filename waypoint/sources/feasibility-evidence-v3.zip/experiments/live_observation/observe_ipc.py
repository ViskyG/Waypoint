#!/usr/bin/env python3
"""Read an existing VS Code IPC owner stream and live JSONL; never drive a turn.
Private, version-specific IPC framing is inferred from installed extension source.
All payloads remain in memory. Export counters, schema and timing only.
"""
import collections,hashlib,json,os,re,selectors,socket,struct,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TARGET=os.environ.get('CODEX_THREAD_ID');assert TARGET,'Missing current thread id'
paths=list((Path.home()/'.codex/sessions').rglob('*'+TARGET+'*.jsonl'));assert len(paths)==1
source=paths[0].open('rb');source.seek(0,2);initial_offset=source.tell();pending=b''
sock=socket.socket(socket.AF_UNIX);sock.settimeout(3);sock.connect(str(Path.home()/'.codex/ipc/ipc.sock'));sock.setblocking(False)
sel=selectors.DefaultSelector();sel.register(sock,selectors.EVENT_READ);wire=b'';client='initializing-client';seq=0;responses={};calls=[]
counts=collections.Counter();schema=collections.Counter();enum_types=collections.Counter();source_events={};stream_seen={};api_seen={};samples=[];revisions={};last_poll=None
state=None;state_revision=None;state_item_types=collections.Counter();patch_gaps=0
allowed={'initialize','thread-owner-discovery','thread-follower-load-complete-history'}
start=time.monotonic();baseline_complete=False;owner=None;subscribed=False;pending_api_revision=None
IDKEYS={'id','itemId','item_id','callId','call_id','toolCallId','messageId','message_id','tool_use_id'}
def token(kind,value):return kind+':'+hashlib.sha256(value.encode()).hexdigest()
def lifecycle(obj):
 out=set()
 if isinstance(obj,dict):
  typ=obj.get('type','');typ=typ[:1].lower()+typ[1:] if isinstance(typ,str) else ''
  ident=obj.get('id');status=obj.get('status')
  if typ in ['commandExecution','mcpToolCall','fileChange'] and ident and status in ['completed','failed','declined']:
   out.add(token('terminal-item',str(ident)+'|'+typ+'|'+status))
  if typ=='agentMessage' and ident:out.add(token('message-item',str(ident)))
  for v in obj.values():
   if isinstance(v,(dict,list)):out|=lifecycle(v)
 elif isinstance(obj,list):
  for v in obj:out|=lifecycle(v)
 return out
def patch_state(change):
 global state,state_revision,patch_gaps,state_item_types
 if change.get('type')=='snapshot':state=change['conversationState'];state_revision=change['revision']
 elif change.get('type')=='patches':
  if state is None or change.get('baseRevision')!=state_revision:patch_gaps+=1;return
  for patch in change.get('patches',[]):
   path=patch['path'];op=patch['op']
   if not path:state=patch.get('value');continue
   target=state
   for key in path[:-1]:target=target[key]
   key=path[-1]
   if op=='remove':target.pop(key) if isinstance(target,dict) else target.pop(int(key))
   elif op=='add' and isinstance(target,list):target.insert(int(key),patch['value'])
   else:target[key]=patch['value']
  state_revision=change['revision']
 def visit(o):
  if isinstance(o,dict):
   if o.get('type') in ['agentMessage','userMessage','commandExecution','mcpToolCall','fileChange']:state_item_types[o['type']]+=1
   for v in o.values():
    if isinstance(v,(dict,list)):visit(v)
  elif isinstance(o,list):
   for v in o:visit(v)
 state_item_types=collections.Counter();visit(state)
def extract(obj,depth=0):
 out=set()
 if isinstance(obj,dict):
  for key,value in obj.items():
   if key in IDKEYS and isinstance(value,str) and value!=TARGET:out.add(token('id',value))
   if key in ['text','message','content'] and isinstance(value,str) and len(value)>8:out.add(token('text',value))
   if isinstance(value,(dict,list)):out|=extract(value,depth+1)
 elif isinstance(obj,list):
  for item in obj:out|=extract(item,depth+1)
 return out

def shapes(obj,prefix='',depth=0):
 if depth>5:return
 if isinstance(obj,dict):
  for key,value in obj.items():
   k=key if len(key)<70 and '/' not in key and not re.search(r'[0-9a-f]{8}-[0-9a-f-]{27,}',key,re.I) else '<dynamic-key>'
   schema[prefix+k+':'+type(value).__name__]+=1
   if k=='type' and isinstance(value,str) and value.replace('_','').replace('-','').isalnum() and len(value)<50:enum_types[value]+=1
   if k not in ['content','text','message','arguments','input','output','instructions']:shapes(value,prefix+k+'.',depth+1)
 elif isinstance(obj,list):
  for v in obj[:8]:shapes(v,prefix+'[].',depth+1)

def send(msg):
 raw=json.dumps(msg).encode();sock.setblocking(True);sock.settimeout(3);sock.sendall(struct.pack('<I',len(raw))+raw);sock.setblocking(False)
def read_tail():
 global pending
 pending+=source.read()
 while b'\n' in pending:
  line,pending=pending.split(b'\n',1)
  try:e=json.loads(line)
  except ValueError:continue
  p=e.get('payload',{});kind=p.get('type') if isinstance(p,dict) else None
  category=None
  if e.get('type')=='response_item' and kind=='message' and p.get('role')=='assistant':category='assistant_message'
  elif e.get('type')=='event_msg' and kind=='agent_message':category='assistant_message'
  elif e.get('type')=='response_item' and kind in ['custom_tool_call','function_call']:category='tool_call'
  elif e.get('type')=='response_item' and kind in ['custom_tool_call_output','function_call_output']:category='tool_output'
  elif e.get('type')=='event_msg' and kind and any(x in kind for x in ['exec_command','mcp_tool_call','patch_apply']):category='tool_event'
  elif e.get('type')=='event_msg' and kind=='item_completed':
   item=p.get('item',{});itype=item.get('type')
   category='terminal_tool_event' if itype in ['CommandExecution','FileChange','McpToolCall'] else 'completed_message' if itype=='AgentMessage' else None
   if category:
    for k in lifecycle(item):source_events.setdefault(k,{'seen':time.monotonic(),'category':category,'event_timestamp':e.get('timestamp')})
  if category:
   for k in extract(p):source_events.setdefault(k,{'seen':time.monotonic(),'category':category,'event_timestamp':e.get('timestamp')})
def receive(wait=.05):
 global wire
 read_tail()
 for _,_ in sel.select(wait):
  chunk=sock.recv(1048576)
  if not chunk:raise ConnectionError('IPC connection closed')
  wire+=chunk
 while len(wire)>=4:
  n=struct.unpack('<I',wire[:4])[0]
  if not 0<n<=45*1024*1024:raise ValueError('Invalid IPC frame')
  if len(wire)<n+4:break
  obj=json.loads(wire[4:n+4]);wire=wire[n+4:];now=time.monotonic()
  if obj.get('type')=='response':responses[obj.get('requestId')]=obj
  elif obj.get('type')=='client-discovery-request':
   send({'type':'client-discovery-response','requestId':obj['requestId'],'response':{'canHandle':False}})
  elif obj.get('type')=='broadcast':
   counts[obj.get('method','unknown')]+=1
   params=obj.get('params',{})
   if params.get('conversationId')==TARGET:
    counts['target:'+obj.get('method','unknown')]+=1;shapes(params)
    if obj.get('method')=='thread-stream-state-changed':
     change=params.get('change',{});rev=change.get('revision');patch_state(change);keys=extract(change)|lifecycle(state)
     for k in keys:stream_seen.setdefault(k,now)
     if isinstance(rev,int):revisions[rev]=(now,keys,change.get('type'))

def rpc(method,params,version=0,target=None):
 global seq
 assert method in allowed
 seq+=1;rid='waypoint-'+str(seq);request={'type':'request','requestId':rid,'sourceClientId':client,'version':version,'method':method,'params':params,'timeoutMs':3000}
 if target:request['targetClientId']=target
 t=time.monotonic();send(request)
 while rid not in responses and time.monotonic()-t<4:receive(.05)
 response=responses.pop(rid,{});error=response.get('error')
 if error and error not in ['no-client-found','request-timeout','client-disconnected','request-version-mismatch']:error='<client diagnostic omitted>'
 calls.append({'method':method,'result':response.get('resultType','timeout'),'error':error,'roundtrip_ms':(time.monotonic()-t)*1000,'result_keys':list(response.get('result',{})) if isinstance(response.get('result'),dict) else []})
 return response
try:
 init=rpc('initialize',{'clientType':'waypoint-readonly-probe'});client=init['result']['clientId']
 found=rpc('thread-owner-discovery',{'hostId':'local','conversationId':TARGET},1)
 if found.get('resultType')=='success':owner=found['handledByClientId']
 if owner:
  send({'type':'broadcast','method':'thread-stream-following-changed','sourceClientId':client,'targetClientIds':[owner],'version':1,'params':{'hostId':'local','conversationId':TARGET,'following':True}});subscribed=True
  for _ in range(10):receive(.05)
  # One read-only history hydration establishes initial state; it cannot start a turn.
  initial_api=rpc('thread-follower-load-complete-history',{'conversationId':TARGET},1,owner)
  for _ in range(4):receive(.05)
  # Remove pre-existing items from the measured freshness cohort.
  source_events.clear();stream_seen.clear();api_seen.clear();revisions.clear();last_poll=time.monotonic()
  marker=HERE/'finish-live-observation'
  if marker.exists():marker.unlink()
  print(json.dumps({'phase':'LIVE_IPC_OBSERVER_READY','owner_found':True,'following':True,'initial_history_read':initial_api.get('resultType')}),flush=True)
  deadline=time.monotonic()+50;polls=0
  while time.monotonic()<deadline and not marker.exists():
   receive(.05)
   needs_read=any(k.startswith('terminal-item:') and k not in api_seen for k in source_events)
   if needs_read and time.monotonic()-last_poll>=.5 and polls<6:
    response=rpc('thread-follower-load-complete-history',{'conversationId':TARGET},1,owner);polls+=1;last_poll=time.monotonic()
    rev=response.get('result',{}).get('revision')
    # API returns a revision; items are delivered in its corresponding snapshot.
    end=time.monotonic()+1
    while isinstance(rev,int) and rev not in revisions and time.monotonic()<end:receive(.05)
    if rev in revisions:
     for k in revisions[rev][1]:api_seen.setdefault(k,time.monotonic())
  for _ in range(2):receive(.05)
 else:initial_api={}
finally:
 if subscribed:
  send({'type':'broadcast','method':'thread-stream-following-changed','sourceClientId':client,'targetClientIds':[owner],'version':1,'params':{'hostId':'local','conversationId':TARGET,'following':False}})
 sock.close();source.close()

matched=[]
for k,e in source_events.items():
 if k in stream_seen or k in api_seen:
  matched.append({'category':e['category'],'key_kind':k.split(':')[0],
    'ipc_minus_jsonl_detection_ms':(stream_seen[k]-e['seen'])*1000 if k in stream_seen else None,
    'api_minus_jsonl_detection_ms':(api_seen[k]-e['seen'])*1000 if k in api_seen else None})
result={'evidence':'REAL','transport':'existing VS Code private IPC Unix socket, 4-byte little-endian JSON frames; not App Server WebSocket',
 'owner_found':bool(owner),'calls':calls,'broadcast_counts':dict(counts),'target_schema':dict(schema),'target_type_values':dict(enum_types),
 'window_seconds':time.monotonic()-start,'source_bytes_appended':source.tell()-initial_offset if not source.closed else paths[0].stat().st_size-initial_offset,
 'source_token_count':len(source_events),'stream_token_count':len(stream_seen),'matched_freshness_samples':matched,
 'reconstructed_state_item_counts':dict(state_item_types),'patch_gaps':patch_gaps,
 'model_turn_commands_sent':0,'extra_inference_turns':0,'subscription_removed':subscribed,'connection_closed':True,
 'freshness_method':'current owner API revision + current snapshot/push compared with in-place active JSONL, no SQLite snapshot; read on new terminal source event with 500ms floor <=6; tail/select 50ms; monotonic receive times',
 'limits':'timing sample keys may describe same item/text twice; negative deltas mean IPC observed first; not generation-to-delivery latency; private protocol version-dependent'}
(ROOT/'reports/P09_direct_ipc.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='target_schema'},indent=2))
