#!/usr/bin/env python3
import json,re,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'reports'
def read(p):return json.loads((R/p).read_text())
def dump(p,o):(R/p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def write(p,s):(R/p).write_text(s.strip()+'\n')
ipc=read('P09_direct_ipc.json');transport=read('P09_transports.json');tree=read('P11_real_lineage.json')
samples=[s for s in ipc['matched_freshness_samples'] if s['key_kind']=='terminal-item' and s['api_minus_jsonl_detection_ms'] is not None]
assert ipc['owner_found'] and ipc['patch_gaps']==0 and samples
assert tree['status']=='PASS' and all(e['parent_spawn_output_task_name_equals_child_agent_path'] for e in tree['edge_corrobation'])
fresh={'status':'PASS','evidence':'REAL','api':'existing owner VS Code IPC thread-follower-load-complete-history; revision response linked to same-revision snapshot',
 'not_measured':'direct official thread/turns/list RPC to current stdio server: no shared App Server endpoint exposed',
 'same_active_client':True,'immutable_sqlite_snapshot_used':False,'new_inference_turns':0,'samples':samples,
 'logical_completed_items':len(samples),'poll_receive_step_ms':50,'read_on_new_terminal_item_floor_ms':500,
 'api_reads_after_baseline':len([x for x in ipc['calls'] if x['method']=='thread-follower-load-complete-history'])-1,
 'api_roundtrips_ms':[x['roundtrip_ms'] for x in ipc['calls'] if x['method']=='thread-follower-load-complete-history'],
 'p50_p95':'NOT_ESTIMATED: one completed item; no claim of latency distribution',
 'method':'key=item.id + normalized item.type + terminal status; local monotonic first-detection timestamps; only completed items compared, generic ID matches excluded',
 'limit':'API revision confirms current owner state with matching snapshot, not a raw App Server item response. Detection delta is affected by polling and scheduling; not generation-to-delivery latency'}
dump('P10_freshness.json',fresh)
rows='\n'.join(f'| {i+1} | {s["ipc_minus_jsonl_detection_ms"]:.3f} | {s["api_minus_jsonl_detection_ms"]:.3f} |' for i,s in enumerate(samples))
report=f'''# Waypoint — прямое наблюдение, свежесть и реальное родство

Дата: 16 октября 2026, Asia/Tbilisi. Дополнение к исходным пробам, редакция 3.
Новых модельных turns / новых агентов: **0 / 0**. Наблюдалась естественная работа текущего исходного клиента. Другие процессы не перезапускались; их transport/config/hooks не менялись. Соединение наблюдателя закрыто, following=False отправлен перед отключением. Оригинальная история не копировалась в отчет; полезная нагрузка IPC разбиралась в памяти.

| Запрос | Итог | Что реально установлено | Граница результата |
|---|---|---|---|
| 1. Общий интерфейс существующего клиента | PARTIAL / REAL | Живой private Unix IPC VS Code позволяет второму клиенту получать snapshot+patches; владелец текущей нити найден | Стандартного общего App Server Unix/WS endpoint у текущего исполнителя нет |
| 2. Свежесть JSONL ↔ API | PASS / REAL в указанном интерфейсе | Один завершенный item сопоставлен по ID+типу+terminal status в живых источниках | Это owner IPC API, не прямой thread/turns/list; n=1, без статистических гарантий |
| 3. Настоящий второй уровень | PASS / REAL, исторический случай | R0 → A1 → A2, depth 1/2, parent IDs и результаты spawn согласованы | Не запускалась новая тройка агентов и не наблюдалось ее одновременное выполнение |

## 1. Подключение к существующему исполнителю

В основном PID/network namespace найден процесс App Server, держащий открытым rollout текущей нити. stdin/stdout — pipe, Unix/TCP listeners у этого процесса не обнаружены. Его родитель — установленный process-hud bridge внутри клиента VS Code. Read-only запрос bridge `status` подтвердил initialized=True, соответствие server_pid, наличие текущей нити и ее active turn. Сам bridge поддерживает только status/deliver; **deliver не вызывался**, произвольного RPC/подписки у него нет.

Стандартный `$USER_HOME/.codex/app-server-control/app-server-control.sock` существует, mode 0600, но и официальная `codex app-server daemon version`, и обычный connect дали ECONNREFUSED (111). Файл сокета не является доказательством работающего сервера. Демон не запускался и не перезапускался.

Другой существующий endpoint — `$USER_HOME/.codex/ipc/ipc.sock`, владелец процесса `code`. Это **внутренний клиентский IPC**, а не WebSocket App Server: четырехбайтовая little-endian длина + JSON. Формат установлен по исходнику уже установленного расширения `openai.chatgpt-26.930.61225-linux-x64`. Внешний код не скачивался, учетные данные не извлекались, идентичность существующего клиента не подменялась: наблюдатель регистрировался с собственным clientType=waypoint-readonly-probe и новым выданным ID.

Выполнены initialize, read-only thread-owner-discovery; затем отправлен following=True для текущей нити и найденного owner. Получены **{ipc['broadcast_counts'].get('target:thread-stream-state-changed',0)}** target thread-stream-state-changed за {ipc['window_seconds']:.2f} с, snapshot и последующие patches. Восстановленная state-проекция содержала agentMessage={ipc['reconstructed_state_item_counts'].get('agentMessage',0)}, userMessage={ipc['reconstructed_state_item_counts'].get('userMessage',0)}, commandExecution={ipc['reconstructed_state_item_counts'].get('commandExecution',0)}, mcpToolCall={ipc['reconstructed_state_item_counts'].get('mcpToolCall',0)}, fileChange={ipc['reconstructed_state_item_counts'].get('fileChange',0)}. Это типы/счетчики реальных объектов, а не имитированные сообщения. Ревизии применялись по baseRevision; пропуски patches={ipc['patch_gaps']}. Текст команд, сообщений, reasoning и результаты инструментов в сдаваемые файлы не сохранялись.

Read-only thread-follower-load-complete-history реально обработан владельцем нити. Он возвращает revision, а соответствующий snapshot содержит текущую проекцию. По установленному исходнику этот путь читает историю/публикует снимок состояния, не запускает модельный turn. Запросы start/steer/interrupt/resume/fork и approval decisions не отправлялись.

Вывод: **наблюдать используемый клиент вторым читателем получилось через его private IPC**. Подключение вторым клиентом к официальному App Server Unix/WS транспорту текущего процесса не получилось по конкретной причине — такой listener не предоставлен в его нынешнем запуске. Эти два результата нельзя объединять в утверждение о поддержанном официальном API.

[Официальная документация App Server](https://learn.chatgpt.com/docs/app-server#protocol) описывает stdio, WebSocket и Unix WebSocket transports; наличие этих возможностей в продукте не означает, что текущий stdio-процесс уже открыл общий listener. Новый сервер с нужным listener не выдавался за существующий исполнитель.

## 2. Свежесть живых источников

Исходный файл читался **на месте**, только целые дописанные JSONL-строки. Его рост в финальном окне: {ipc['source_bytes_appended']} байт. Ни SQLite backup, ни неизменяемый индекс в этом замере не использовались. API-запросы шли существующему owner через тот же IPC, который транслировал состояние исходного клиента.

Сопоставлялся `event_msg/item_completed.item`: **одинаковые item.id, тип и terminal status** в JSONL и восстановленном текущем состоянии. Формат CommandExecution в журнале нормализован к commandExecution в UI. Это важное отличие от простого совпадения ID: IPC может показать in-progress item раньше, чем JSONL запишет его завершение; такое совпадение не измеряет свежесть одного и того же состояния и исключено из итоговых чисел.

Локальный perf_counter/monotonic фиксировал момент первого обнаружения. При новом terminal item выполнялось чтение owner API; возвращенная revision связывалась со snapshot той же revision, содержащим тот же terminal item. Шаг tail/select — до 50 мс; между API reads установлен минимум 500 мс, максимум 6 запросов после baseline. В финальном прогоне понадобился {fresh['api_reads_after_baseline']} запрос после baseline.

| Завершенный item | IPC detection − JSONL detection, мс | API revision/snapshot detection − JSONL detection, мс |
|---|---|---|
{rows}

Это **{len(samples)} контрольный item**, а не p50/p95. Около 0,5 мс находится внутри разрешения цикла наблюдения до 50 мс и не доказывает субмиллисекундную доставку. Разница API около 47 мс включает запрос/обработку/получение snapshot, не является обещанием lag Codex. Roundtrip baseline и следующего history read: {fresh['api_roundtrips_ms']}. Время генерации события до записи не измерялось.

Прямой freshness `thread/turns/list` на текущем stdio App Server **не измерен**: нет доступного второго транспорта к нему. Полученный положительный результат относится к read-only API действующего владельца VS Code. Прежнее поведение отдельного сервера с SQLite-снимком остается только проверкой того снимка; из него нельзя выводить отставание живого API Codex.

## 3. Реальная вложенная оркестрация

Проверены заголовки {tree['sessions_indexed']} существующих собственных rollout-файлов (без выгрузки содержимого). В {tree['explicit_parent_metadata_count']} есть parent_thread_id; обнаружено {tree['two_edge_chains_with_all_files']} цепочек из двух ребер с доступными тремя файлами. Максимум наблюдаемых parent hops — {tree['max_observed_parent_hops']}. Отсутствующих предков и циклов в этом срезе не обнаружено. Эти числа характеризуют доступную историю, не предел возможностей Codex.

Для одного выбранного реального случая полностью проверена цепь **R0 → A1 → A2**. Это псевдонимы; настоящие UUID и task paths не экспортировались.

| Объект | payload.id | payload.parent_thread_id | source.subagent.thread_spawn.parent_thread_id | depth |
|---|---|---|---|---|
| R0 | собственный root ID | отсутствует | отсутствует | — |
| A1 | отдельный ID | равен R0.id | равен R0.id | 1 |
| A2 | отдельный ID | равен A1.id | равен A1.id | 2 |

Оба ребра дополнительно подтверждены **родительскими журналами**: в R0 был реальный spawn_agent, его output.task_name точно равен A1.agent_path; в A1 был spawn_agent, его output.task_name точно равен A2.agent_path. Связь не выводилась из похожих имен. Spawn output в этом случае возвращает task_name, а не UUID; утверждать обратное нельзя.

Важная особенность: у A1 и A2 `payload.session_id` совпадает с root container session_id, хотя `payload.id` у них различается. Поэтому для данного формата distinct thread key — **payload.id**, parent key — **payload.parent_thread_id**; session_id нельзя безусловно считать ID каждого отдельного агента. source.thread_spawn.depth и agent_path — дополнительные поля, не замена parent ID. `forked_from_id` следует хранить отдельно от родства spawn.

Это **настоящая историческая оркестрация**, не синтетика. Одновременная живая работа новой тройки не тестировалась. Дополнительное разрешение на новый модельный эксперимент не потребовалось, поскольку существующая история уже дала проверяемый реальный случай.

## Архитектурные следствия

- Для нынешнего VS Code доступен работающий адаптер snapshot+patches через private IPC с owner discovery и контролем revisions. Протокол привязан к версии расширения; его нельзя объявлять стабильным официальным App Server API. Нужны capability probe и fallback к JSONL.
- Для официального второго App Server клиента потребуется, чтобы используемый исполнитель изначально обслуживался сервером с Unix/WS listener. Это изменение запуска/клиента — отдельная работа; текущие процессы не трогались.
- Свежесть сравнивать по item ID **и состоянию/ревизии**, отдельно push, API-read и файл. Не смешивать появление in-progress item с завершением и не заменять живой индекс неизменяемой копией.
- Реальное родство можно восстанавливать по метаданным; в исследованном формате использовать payload.id, а не общий session_id. Идентификатор потока, container session и agent/task path должны быть разными полями Waypoint.

## Доказательства и воспроизведение

- P09_inventory.json — read-only инвентаризация host namespace, без полных argv/env.
- P09_transports.json — привязка server↔rollout↔bridge, read-only status и ECONNREFUSED официального control socket.
- P09_direct_ipc.json — очищенные счетчики, типы полей, методы и результаты финального live-прогона. Предыдущие прогоны сохранены отдельно; generic ID timing не использовался как completed-event freshness.
- P10_freshness.json — только корректно сопоставленные terminal items; n={len(samples)}.
- P11_real_lineage.json — псевдонимизированные узлы, числовой depth и равенства ID/task paths; ни одного реального ID/path в отчете.
- Минимальные исходники experiments/live_observation: inventory_host.py, verify_transports.py, observe_ipc.py, real_lineage.py. Для host PID/socket доступа может потребоваться разрешенный запуск вне ограниченного PID namespace. observe_ipc читает текущую нить из существующего CODEX_THREAD_ID, работает до 50 секунд или до файла finish-live-observation и сам снимает following перед закрытием.

Проверки не создавали новых model turns, агентов, PR, hooks или конфигураций. Данные не отправлялись в облачные сервисы. В ZIP включены только исходники и санитизированные отчеты; сырая история/IPC payloads/UUID/credentials отсутствуют. Размеры и hashes архивов — в delivery-manifest.json.
'''
write('FOLLOWUP_REAL_SESSION_RU.md',report)
# Keep the original nine probe statuses comparable; add separately scoped real followups.
summary=read('SUMMARY.json');summary['revision']='3: existing-client private IPC, no-snapshot freshness, historical real depth-2 lineage'
summary['external_live_observation']='REAL: existing VS Code owner IPC follower stream; official App Server shared listener absent on current executor'
summary['followups']={
 'DIRECT_EXISTING_CLIENT':{'status':'PARTIAL','evidence':'REAL','finding':'private VS Code IPC receives owner snapshots and patches; official shared server listener absent'},
 'EVENT_FRESHNESS':{'status':'PASS','evidence':'REAL','finding':f'{len(samples)} terminal item matched in live JSONL, push and owner IPC API; no SQLite snapshot','scope':'owner client API; direct thread/turns/list unmeasured'},
 'REAL_DEPTH_TWO':{'status':'PASS','evidence':'REAL','finding':'historical R0 -> A1 -> A2 corroborated by child metadata and parent spawn output task_name; root session_id shared','scope':'historical real case, not new live triple'}}
dump('SUMMARY.json',summary)
cap=read('capabilities.json');cap['live_external_subscription']='yes via existing VS Code private IPC follower stream; no official shared App Server endpoint found'
cap['real_nested_lineage']='yes: historical depth 2 cross-checked; metadata.id distinct from shared session_id'
dump('capabilities.json',cap)
# Add an explicit correction before older narrative so its scope cannot be mistaken.
main=(R/'RETURN_TO_CHAT_RU.md').read_text();notice='''> **Редакция 3, дополнение:** [FOLLOWUP_REAL_SESSION_RU.md](FOLLOWUP_REAL_SESSION_RU.md) содержит новые реальные проверки. Наблюдение существующего клиента через private Unix IPC VS Code **подтверждено**; официального общего App Server listener у текущего исполнителя нет. Freshness проверена без копии SQLite на одном terminal item через owner API и JSONL. Реальная историческая цепочка второго уровня подтверждена parent IDs и родительскими spawn outputs. Ниже сохранены исходные девять проб и их ограниченный первоначальный объем; прежние «не установлено» о live/родстве относятся к тому объему, а не ко всем результатам редакции 3.'''
if '> **Редакция 3, дополнение:**' not in main:main=main.replace('\n\n','\n\n'+notice+'\n\n',1)
write('RETURN_TO_CHAT_RU.md',main)
for name in ['P02.md','P03.md','P01.md']:
 s=(R/name).read_text()
 note='\n\n**Дополнение редакции 3:** новые реальные результаты наблюдения через текущий owner IPC, freshness и родства приведены в [FOLLOWUP_REAL_SESSION_RU.md](FOLLOWUP_REAL_SESSION_RU.md). Утверждения выше сохраняют объем первоначальной пробы; не распространять прежние UNKNOWN на новые доказательства.\n'
 if '**Дополнение редакции 3:**' not in s:write(name,s+note)
write('REVISION_3.md','''# Новые реальные проверки

Подтвержден существующий private Unix IPC VS Code с owner discovery и following: реальные snapshots/patches и сообщения/инструменты текущего клиента. Официальный App Server работает stdio и общего listener не предоставляет; control socket ECONNREFUSED.

Freshness измерена на живом owner API и JSONL без SQLite-копии. Для одного completed item совпали ID, тип и terminal status; один замер не заменяет распределение задержек. Реальная историческая цепочка R0 → A1 → A2 подтверждена метаданными и результатами spawn; дополнительных агентов/turns не создавалось.

Основной документ: FOLLOWUP_REAL_SESSION_RU.md. Ранее наблюдавшаяся неизменность отдельного сервера со снимком SQLite не является доказательством отставания живого API Codex.
''')
print(json.dumps({'followup_report':'reports/FOLLOWUP_REAL_SESSION_RU.md','completed_freshness_samples':len(samples),'real_lineage':'PASS','additional_inference_turns':0}))
