#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def build(events):
    index={}; parents={}; focus={}; links={}; issues=[]; statuses={}
    for e in events:
        eid=e.get('event_id')
        if not eid: issues.append('missing_event_id'); continue
        if eid in index: continue
        index[eid]=e; aid=e.get('agent_id')
        if not aid: issues.append('missing_agent_id'); continue
        if e['type']=='agent.started': parents[aid]=e.get('parent_agent_id'); statuses[aid]='active'
        if e['type']=='agent.stopped': statuses[aid]='stopped'
        if e['type']=='agent.focus': focus[aid]=e.get('block_ids',[])
        for bid in e.get('block_ids',[]): links.setdefault((aid,bid),set()).add(eid)
    for aid in parents:
        seen=set(); cur=aid
        while cur is not None:
            if cur in seen: issues.append('parent_cycle'); break
            seen.add(cur)
            if cur not in parents: issues.append('unknown_parent'); break
            cur=parents[cur]
    unknown=sorted({e.get('agent_id') for e in index.values()}-set(parents)-{'observer'})
    return index,parents,focus,links,issues,statuses,unknown
def main():
    events=[json.loads(x) for x in (ROOT/'fixtures/events.synthetic.jsonl').read_text().splitlines()]
    index,parents,focus,links,issues,statuses,unknown=build(events)
    graph=json.loads((ROOT/'fixtures/graph-v1.json').read_text())
    def projection(bid,desc=False):
        scope={bid}
        if desc:
            for _ in graph['nodes']:
                scope|={n['id'] for n in graph['nodes'] if n['parent_id'] in scope}
        return [eid for eid,e in index.items() if set(e.get('block_ids',[])) & scope]
    assert parents['A4']=='A3' and parents['A3']=='O1'
    assert focus['A2']==['W-02','W-03'] and len(index)==17
    assert statuses['O1']=='stopped' and statuses['A4']=='active'
    assert len(projection('W-03',True))>len(projection('W-03'))
    mutant=[{'event_id':str(i),'type':'agent.started','agent_id':a,'parent_agent_id':p} for i,(a,p) in enumerate([('X','Y'),('Y','X'),('Z','missing')])]+[{}]
    bad=build(mutant)[4]
    assert {'parent_cycle','unknown_parent','missing_event_id'}<=set(bad)
    out={'source':'SYNTHETIC','unique_events':len(index),'duplicate_events':len(events)-len(index),
      'parents':parents,'dual_roles':[a for a in parents if a in parents.values() and parents[a]],
      'current_focus':focus,'statuses':statuses,'unknown_origin_agents':unknown,
      'agent_block_refs':[{'agent':a,'block':b,'event_refs':sorted(v)} for (a,b),v in links.items()],
      'edge_refs':[eid for eid,e in index.items() if e.get('edge')],
      'outside_map_refs':[eid for eid,e in index.items() if not e.get('block_ids') and not e.get('edge')],
      'direct_W03':projection('W-03'),'descendants_W03':projection('W-03',True),
      'invalid_input_detected':sorted(set(bad)),'checks':'PASS',
      'real_mapping':{'session':'payload.session_id/id','turn':'payload.turn_id','item_or_tool':'payload.id/call_id',
                      'parent_agent':'UNKNOWN: not observed in selected rollout','block':'absent; explicit protocol needed'}}
    (ROOT/'reports/P03_observation.json').write_text(json.dumps(out,indent=2)+'\n')
    print('P03 PASS SYNTHETIC: tree, M:N links, projections, invalid hierarchy, orphan activity')
if __name__=='__main__': main()
