#!/usr/bin/env python3
import copy, hashlib, json, sqlite3, subprocess, time, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).parent; REPO=HERE/'scratch-repo'
def git(*args):
    return subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],cwd=REPO,check=True,capture_output=True,text=True).stdout.strip()
def nodes(g): return {n['id']:n for n in g['nodes']}
def merge(base,left,right):
    # Field-based three-way graph-node merge, explicit conflict; no LWW.
    out=copy.deepcopy(right); result=nodes(out); b,l,r=map(nodes,[base,left,right]); conflicts=[]
    for ident in set(b)|set(l)|set(r):
        for field in set(b.get(ident,{}))|set(l.get(ident,{}))|set(r.get(ident,{})):
            bv,lv,rv=[m.get(ident,{}).get(field) for m in [b,l,r]]
            if lv==bv: continue
            if rv!=bv and lv!=rv: conflicts.append(ident+'.'+field)
            else: result.setdefault(ident,{})[field]=lv
    out['nodes']=list(result.values()); return out,conflicts
def main():
    global REPO
    REPO=Path(tempfile.mkdtemp(prefix='scratch-repo-',dir=HERE))
    git('init','-q'); git('config','user.name','Waypoint Synthetic Probe'); git('config','user.email','probe@example.invalid')
    v1=json.loads((ROOT/'fixtures/graph-v1.json').read_text()); v2=json.loads((ROOT/'fixtures/graph-v2.json').read_text())
    path=REPO/'graph.json'; path.write_text(json.dumps(v1,ensure_ascii=False,indent=2)+'\n')
    git('add','graph.json'); git('commit','-qm','synthetic v1'); c1=git('rev-parse','HEAD')
    b,a=nodes(v1),nodes(v2); edges=lambda g:{(e['from'],e['to']) for e in g['dependencies']}
    diff={'added':sorted(a.keys()-b.keys()),'removed':sorted(b.keys()-a.keys()),
          'changed':{k:{f:{'before':b[k].get(f),'after':a[k].get(f)} for f in set(a[k])|set(b[k]) if a[k].get(f)!=b[k].get(f)} for k in a.keys()&b.keys() if a[k]!=b[k]},
          'edges_added':sorted(edges(v2)-edges(v1)),'edges_removed':sorted(edges(v1)-edges(v2)),
          'moved':{k:[b[k]['parent_id'],a[k]['parent_id']] for k in a.keys()&b.keys() if a[k]['parent_id']!=b[k]['parent_id']}}
    event_db=REPO.parent/(REPO.name+'-events.sqlite')
    log=sqlite3.connect(event_db); log.execute('CREATE TABLE events(id INTEGER PRIMARY KEY, body TEXT)')
    before=git('rev-list','--count','HEAD'); t=time.perf_counter()
    for i in range(100): log.execute('INSERT INTO events VALUES(?,?)',(i,json.dumps({'source':'SYNTHETIC','event':i})))
    log.commit(); write_ms=(time.perf_counter()-t)*1000; after=git('rev-list','--count','HEAD')
    assert before==after=='1'; log.close()
    event_hash=hashlib.sha256(event_db.read_bytes()).hexdigest()
    path.write_text(json.dumps(v2,ensure_ascii=False,indent=2)+'\n')
    textstat=git('diff','--stat'); git('add','graph.json'); git('commit','-qm','synthetic v2 checkpoint'); c2=git('rev-parse','HEAD')
    assert json.loads(git('show',c1+':graph.json'))==v1 and json.loads(git('show',c2+':graph.json'))==v2
    assert 'W-03' not in a and 'W-03' in nodes(json.loads(git('show',c1+':graph.json')))
    assert event_hash==hashlib.sha256(event_db.read_bytes()).hexdigest()
    left=copy.deepcopy(v1); right=copy.deepcopy(v1)
    left['nodes'][0]['task']='synthetic independent task'
    right['nodes'][1]['acceptance']='synthetic independent acceptance'
    merged,conflict=merge(v1,left,right); assert not conflict
    assert nodes(merged)['W-01']['task']==left['nodes'][0]['task'] and nodes(merged)['W-02']['acceptance']==right['nodes'][1]['acceptance']
    left=copy.deepcopy(v1); right=copy.deepcopy(v1)
    left['nodes'][1]['acceptance']='left'; right['nodes'][1]['acceptance']='right'
    _,conflict=merge(v1,left,right); assert conflict==['W-02.acceptance']
    offline={'base_version':'v1','changed_ids':['W-02'],'operations':[{'op':'replace','id':'W-02','field':'acceptance','value':'offline criterion'}]}
    left=copy.deepcopy(v1); left['nodes'][1]['acceptance']='offline criterion'
    _,stale_conflicts=merge(v1,left,v2); assert stale_conflicts==['W-02.acceptance']
    out={'source':'SYNTHETIC','repo':str(REPO.relative_to(ROOT)),'structural_diff':diff,'v1_commit':c1,'v2_commit':c2,
      'event_writes':100,'event_write_ms':write_ms,'commits_before_after_events':[before,after],
      'git_text_diff':textstat,'history_preserved':True,'removed_node_history_resolvable':True,
      'independent_merge':'PASS','criterion_conflicts':conflict,'offline_package':offline,
      'stale_base_detected':offline['base_version']!=v2['version'],'stale_conflicts':stale_conflicts,
      'checks':'PASS','merge_limit':'only node-field patch spike; deletion/edge/general distributed merge not implemented'}
    (ROOT/'reports/P05_observation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
