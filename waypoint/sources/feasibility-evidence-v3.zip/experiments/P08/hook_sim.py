#!/usr/bin/env python3
"""Synthetic stdin adapter only. Never configured as a real Codex hook."""
import hashlib, importlib.util, json, sqlite3, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
DB=ROOT/'experiments/P04/protocol.sqlite'
def adapter(db,delay=0):
    try:
        e=json.load(sys.stdin)
        safe={k:e[k] for k in ['session_id','hook_event_name','turn_id','agent_id','tool_use_id'] if k in e}
        time.sleep(delay)
        conn=sqlite3.connect(db,timeout=.1)
        body=json.dumps(safe,sort_keys=True)
        conn.execute('INSERT OR IGNORE INTO events VALUES(?,?)',('hook-sim:'+hashlib.sha256(body.encode()).hexdigest(),body)); conn.commit(); conn.close()
    except Exception:
        pass # fail open; no model-visible content, telemetry loss remains a limitation
    return 0

def main():
    sync=[]; dispatch=[]; delivery=[]; streams=[]
    for typ in ['SubagentStart','SubagentStop','PostToolUse','Stop']:
        e={'session_id':'synthetic-parent','hook_event_name':typ,'turn_id':'synthetic-turn','transcript_path':None,'cwd':'synthetic-only','model':'not-used','permission_mode':'default'}
        if typ.startswith('Subagent'): e.update(agent_id='synthetic-child',agent_type='synthetic')
        if typ=='PostToolUse':e.update(tool_use_id='synthetic-tool-call',tool_name='synthetic',tool_input={'ignored':'not persisted'})
        payload=json.dumps(e)
        t=time.perf_counter(); p=subprocess.run([sys.executable,__file__,'--adapter',str(DB),'.05'],input=payload,capture_output=True,text=True,timeout=1)
        sync.append((time.perf_counter()-t)*1000); streams.append([p.returncode,len(p.stdout),len(p.stderr)])
        t=time.perf_counter(); p=subprocess.Popen([sys.executable,__file__,'--adapter',str(DB),'.05'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        p.stdin.write(payload);p.stdin.close();p.stdin=None
        dispatch.append((time.perf_counter()-t)*1000)
        out,err=p.communicate(timeout=1); delivery.append((time.perf_counter()-t)*1000);streams.append([p.returncode,len(out),len(err)])
    t=time.perf_counter(); failed=subprocess.run([sys.executable,__file__,'--adapter',str(HERE/'nonexistent/observer.sqlite'),'0'],input=payload,capture_output=True,text=True,timeout=1)
    fail_ms=(time.perf_counter()-t)*1000
    assert all(s==[0,0,0] for s in streams) and (failed.returncode,failed.stdout,failed.stderr)==(0,'','')
    count=sqlite3.connect(DB).execute("SELECT count(*) FROM events WHERE id LIKE 'hook-sim:%'").fetchone()[0]; assert count==4
    result={'source':'SYNTHETIC','real_hooks':'NOT_TESTED; no configuration or trust modification; no inference',
        'events':['SubagentStart','SubagentStop','PostToolUse','Stop'],'sync_samples_ms':sync,'async_dispatch_samples_ms':dispatch,
        'async_delivery_samples_ms':delivery,'sync_worst_ms':max(sync),'async_dispatch_worst_ms':max(dispatch),
        'collector_unavailable_ms':fail_ms,'stdout_bytes':0,'stderr_bytes':0,'all_exit_codes':0,
        'db_sanitized_rows':count,'input_fields':'documentation-derived; locally fabricated; not observed from installed hooks',
        'delay_injection_ms':50,'scope':'plain subprocess scheduling; NOT actual Codex async hooks',
        'id_stability':'UNKNOWN in actual runtime; local hash is a simulation key only',
        'failure':'fail-open exit 0, silent telemetry loss; real hooks may report their own errors',
        'docs_warning':'current Stop/SubagentStop docs expect JSON stdout on exit 0; empty output adapter from probe is NOT validated against actual hook runtime',
        'checks':'PASS'}
    (ROOT/'reports/P08_observation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    if '--adapter' in sys.argv: sys.exit(adapter(sys.argv[-2],float(sys.argv[-1])))
    main()
