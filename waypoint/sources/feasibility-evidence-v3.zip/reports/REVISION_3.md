# Новые реальные проверки

Подтвержден существующий private Unix IPC VS Code с owner discovery и following: реальные snapshots/patches и сообщения/инструменты текущего клиента. Официальный App Server работает stdio и общего listener не предоставляет; control socket ECONNREFUSED.

Freshness измерена на живом owner API и JSONL без SQLite-копии. Для одного completed item совпали ID, тип и terminal status; один замер не заменяет распределение задержек. Реальная историческая цепочка R0 → A1 → A2 подтверждена метаданными и результатами spawn; дополнительных агентов/turns не создавалось.

Основной документ: FOLLOWUP_REAL_SESSION_RU.md. Ранее наблюдавшаяся неизменность отдельного сервера со снимком SQLite не является доказательством отставания живого API Codex.
