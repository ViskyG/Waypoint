#!/usr/bin/env python3
"""Pack only sanitized reports. Manually inspect them before sending the ZIP."""
from pathlib import Path
import re, sys, zipfile

ROOT = Path(__file__).resolve().parent.parent
REPORTS = ROOT / 'reports'
if not REPORTS.exists():
    raise SystemExit('No reports directory. Generate reports/RETURN_TO_CHAT_RU.md first.')
files = sorted(p for p in REPORTS.iterdir() if p.is_file() and p.suffix.lower() in {'.md', '.json', '.txt'})
if not any(p.name == 'RETURN_TO_CHAT_RU.md' for p in files):
    raise SystemExit('Missing reports/RETURN_TO_CHAT_RU.md')
# Intentionally conservative, not a comprehensive secrets detector.
pat = re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Authorization:\s*Bearer\s+\S+|\b(?:ghp_|github_pat_|sk-)[A-Za-z0-9_\-]{16,}',re.I)
for p in files:
    content = p.read_text(encoding='utf-8')
    if pat.search(content):
        raise SystemExit(f'Potential secret in {p.name}; redact manually and retry.')
out = ROOT / 'WAYPOINT_CODEX_RESULTS_SANITIZED.zip'
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, f'reports/{p.name}')
print('Created', out)
print('Included:', ', '.join(p.name for p in files))
print('NOTE: review all included text for personal data manually before sharing.')
