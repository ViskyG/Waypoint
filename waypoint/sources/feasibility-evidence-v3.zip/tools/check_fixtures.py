#!/usr/bin/env python3
"""Deterministic self-check of ONLY the bundled synthetic fixtures; no Codex calls."""
from collections import Counter
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
F = ROOT / 'fixtures'

def load_graph(name):
    g = json.loads((F / name).read_text(encoding='utf-8'))
    assert g['schema'] == 'waypoint-graph/v0-probe'
    ids = [n['id'] for n in g['nodes']]
    assert len(ids) == len(set(ids)), 'duplicate node ID'
    nodes = {n['id']: n for n in g['nodes']}
    for n in g['nodes']:
        assert n['parent_id'] is None or n['parent_id'] in nodes, 'invalid parent'
        assert n['layout_hint'] in ('horizontal', 'vertical')
        assert n.get('task') and n.get('acceptance')
    edges = [(e['from'], e['to']) for e in g['dependencies']]
    assert len(edges) == len(set(edges)), 'duplicate graph edge'
    assert all(a in nodes and b in nodes for a, b in edges)
    def visit(n, stack, done):
        assert n not in stack, 'dependency cycle'
        if n in done: return
        stack.add(n)
        for a, b in edges:
            if a == n: visit(b, stack, done)
        stack.remove(n)
        done.add(n)
    done = set()
    for n in ids: visit(n, set(), done)
    return g

v1 = load_graph('graph-v1.json')
v2 = load_graph('graph-v2.json')
assert v2['base_version'] == v1['version']
n1 = {x['id']: x for x in v1['nodes']}
n2 = {x['id']: x for x in v2['nodes']}
added = sorted(n2.keys() - n1.keys())
removed = sorted(n1.keys() - n2.keys())
modified = sorted(k for k in n1.keys() & n2.keys() if n1[k] != n2[k])
assert added == ['W-06'], added
assert removed == ['W-03', 'W-03.1'], removed
assert modified == ['W-02'], modified

lines = (F / 'events.synthetic.jsonl').read_text(encoding='utf-8').splitlines()
events = [json.loads(line) for line in lines]
assert all(e['source'] == 'SYNTHETIC' for e in events)
counts = Counter(e['event_id'] for e in events)
assert len(events) == 18 and len(counts) == 17, counts
assert [k for k, v in counts.items() if v == 2] == ['synth-010']
assert any(e.get('parent_agent_id') == 'A3' and e['agent_id'] == 'A4' for e in events)
assert any(len(e['block_ids']) > 1 for e in events)
assert any(e['type'] == 'edge.note' and e['edge'] for e in events)
assert any(e['type'] == 'agent.message' and not e['block_ids'] and not e['edge'] for e in events)
assert any(e['type'] == 'test.result' and e['payload'].get('failed', 0) > 0 for e in events)
assert any(e['type'] == 'block.status' and e['payload'].get('status') == 'done' for e in events)
assert any(e['type'] == 'observation.gap' for e in events)
assert any(e['type'] == 'agent.stopped' and e['agent_id'] == 'O1' for e in events)
print('FIXTURES_OK; synthetic only; no Codex capability tested')
print(f'graph v1={len(n1)} nodes, v2={len(n2)} nodes; +{added}, -{removed}, ~{modified}')
print(f'events lines={len(events)}, unique={len(counts)}, replay_duplicate=synth-010')
